package dio.springboot;

public class Calculadora {
    public int somar(int numero1, int numero2){
        return numero1 + numero2;
    }
}
