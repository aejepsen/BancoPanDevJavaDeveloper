package dio.dio.spring.security.jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DioSpringSecurityJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
