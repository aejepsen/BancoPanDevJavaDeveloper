public class LocacaoVeiculo {
    public static void main(String[] args) {
        Estado rj = Estado.RJ;
        System.out.println(rj.getNome());
        System.out.println(rj.getSigla());

    }
}
