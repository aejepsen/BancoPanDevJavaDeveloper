public class CadastroCliente {
    public static void main(String[] args) {
        Estado sp = Estado.SP;
        System.out.println(sp.getNome());
        System.out.println(sp.getSigla());
        Estado ma = Estado.MA;
        System.out.println(ma.getRegiao());
    }
}
